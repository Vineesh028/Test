/**
 UserController.java
 UserManagementService
 com.test.usermanagement.controller
 TODO
 Author :vineesh.velayudhan
 10-Jan-2024 : 5:23:18 pm
 */
package com.test.usermanagement.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.usermanagement.model.User;

/**
 * 
 */
@RestController
@RequestMapping("/v1/users")
public class UserController {


	@PostMapping("/user")
	public ResponseEntity<User> createUser(@RequestBody User user) {


		return ResponseEntity.ok(null);
	}

	@GetMapping()
	public ResponseEntity<List<User>> getAllUsers() {


		return ResponseEntity.ok(null);
	}

	@GetMapping("/user/{user-id}")
	public ResponseEntity<User> getUser(@PathVariable("user-id") String id) {


		return ResponseEntity.ok(null);
	}

	@PutMapping("/user/{user-id}")
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable("user-id") String id) {


		return ResponseEntity.ok(null);
	}

	@DeleteMapping("/user/{user-id}")
	public ResponseEntity<String> deleteUser(@PathVariable("user-id") String id) {

		return ResponseEntity.ok("");
	}

}