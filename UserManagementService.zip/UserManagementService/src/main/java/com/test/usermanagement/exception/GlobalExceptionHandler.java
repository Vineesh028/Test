/**
 GlobalExceptionHandler.java
 UserManagementService
 com.test.usermanagement.exception
 TODO
 Author :vineesh.velayudhan
 10-Jan-2024 : 2:52:58 pm
 */
package com.test.usermanagement.exception;

import java.io.IOException;
import java.util.Map;

import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.AllArgsConstructor;

/**
 * 
 */
@RestControllerAdvice
@AllArgsConstructor
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    private final ErrorAttributes errorAttributes;

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> appException(Exception ex, WebRequest request) throws IOException {
        Map<String, Object> body = errorAttributes.getErrorAttributes(request, null);//ex.getOptions());
        HttpStatus status =  HttpStatus.ACCEPTED;//= ex.getStatus();
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        return ResponseEntity.status(status).body(body);
    }
}