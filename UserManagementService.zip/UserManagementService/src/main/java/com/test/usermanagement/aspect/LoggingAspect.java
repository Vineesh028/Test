/**
 LoggingAspect.java
 UserManagementService
 com.test.usermanagement.aspect
 TODO
 Author :vineesh.velayudhan
 10-Jan-2024 : 3:44:46 pm
 */
package com.test.usermanagement.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Aspect
@Component
@Slf4j
public class LoggingAspect {

    /**
     * Pointcut that matches all repositories, services and Web REST endpoints.
     */
    @Pointcut("within(@org.springframework.stereotype.Repository *)"
	    + " || within(@org.springframework.stereotype.Service *)"
	    + " || within(@org.springframework.web.bind.annotation.RestController *)")
    public void springBeanPointcut() {
	// Method is empty as this is just a Pointcut, the implementations are in the
	// advices.
    }

    /**
     * Pointcut that matches all Spring beans in the application's main packages.
     */
    @Pointcut("within(com.test.usermanagement..*)" + " || within(com.test.usermanagement.service..*)"
	    + " || within(com.test.usermanagement.controller..*)")
    public void applicationPackagePointcut() {
	// Method is empty as this is just a Pointcut, the implementations are in the
	// advices.
    }

    @Around("applicationPackagePointcut() && springBeanPointcut()")
    public Object profileAllMethods(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
	MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();

	String className = methodSignature.getDeclaringType().getSimpleName();
	String methodName = methodSignature.getName();

	final StopWatch stopWatch = new StopWatch();
	log.debug("Entered into method: " + methodName);
	stopWatch.start();
	Object result = proceedingJoinPoint.proceed();
	stopWatch.stop();
	log.debug("Exited from method: " + methodName);
	log.debug(
		"Execution time of " + className + "." + methodName + " :: " + stopWatch.getTotalTimeMillis() + " ms");
	return result;
    }

    /**
     * TODO LoggingAspect void
     */
    @AfterThrowing(pointcut = "applicationPackagePointcut() && springBeanPointcut()", throwing = "e")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {
	log.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
		joinPoint.getSignature().getName(), e.getCause() != null ? e.getCause() : "NULL");
    }
}
