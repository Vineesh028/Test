/**
 AppConfig.java
 UserManagementService
 com.test.usermanagement.config
 TODO
 Author :vineesh.velayudhan
 10-Jan-2024 : 2:26:09 pm
 */
package com.test.usermanagement.config;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static com.fasterxml.jackson.databind.DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE;
import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.boot.actuate.web.exchanges.HttpExchangeRepository;
import org.springframework.boot.actuate.web.exchanges.InMemoryHttpExchangeRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * 
 */
@Configuration
@EnableWebMvc
public class AppConfig {

    @Bean
    public ObjectMapper objectMapper() {
	return new ObjectMapper().registerModule(new JavaTimeModule()).setSerializationInclusion(NON_NULL)
		.disable(FAIL_ON_UNKNOWN_PROPERTIES).disable(ADJUST_DATES_TO_CONTEXT_TIME_ZONE)
		.disable(WRITE_DATES_AS_TIMESTAMPS).setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

    @Bean
    public CorsFilter corsFilter() {
	final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	final CorsConfiguration config = new CorsConfiguration();
	config.setAllowCredentials(true);
	config.setAllowedOriginPatterns(Collections.singletonList("*"));
	config.setAllowedHeaders(Arrays.asList("Origin", "Content-Type", "Accept"));
	config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "OPTIONS", "DELETE", "PATCH"));
	source.registerCorsConfiguration("/**", config);
	return new CorsFilter(source);
    }

    @Bean
    public HttpExchangeRepository httpTraceRepository() {
	return new InMemoryHttpExchangeRepository();
    }

}
