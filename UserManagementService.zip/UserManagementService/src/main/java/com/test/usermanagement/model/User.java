/**
 User.java
 UserManagementService
 com.test.usermanagement.model
 TODO
 Author :vineesh.velayudhan
 10-Jan-2024 : 5:24:14 pm
 */
package com.test.usermanagement.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 
 */
@Data
public class User {

	@NotBlank
	private String id;

	@NotBlank
	private String name;

	@NotBlank
	private String email;

}